#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "course.h"

Course* createCourse(int courseId, const char* courseName, int credits, Department department) {
    Course* course = (Course*) malloc(sizeof(Course));
    if (!course) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    course->courseId = courseId;
    course->courseName = (char*) malloc((strlen(courseName) + 1) * sizeof(char));
    if (!course->courseName) {
        printf("Memory allocation for course name failed\n");
        free(course);
        return NULL;
    }
    strcpy(course->courseName, courseName);
    course->credits = credits;
    course->department = department;
    return course;
}

void displayCourseInfo(Course* courses, int numCourses) {
    printf("\n--- Course Information ---\n");
    printf("Course ID\tCourse Name\t\tCredits\tDepartment\n");
    for (int i = 0; i < numCourses; i++) {
        printf("%d\t\t%s\t\t%d\t\t", courses[i].courseId, courses[i].courseName, courses[i].credits);
        switch (courses[i].department) {
            case CSE:
                printf("Computer Science and Engineering\n");
                break;
            case EEE:
                printf("Electrical and Electronic Engineering\n");
                break;
            case ICE:
                printf("Information and Communication Engineering\n");
                break;
            case CV:
                printf("Civil Engineering\n");
                break;
            case OTHER:
                printf("Other\n");
                break;
            default:
                printf("Unknown department\n");
                break;
        }
    }
}

void freeCourses(Course* courses, int numCourses) {
    for (int i = 0; i < numCourses; i++) {
        free(courses[i].courseName);
    }
    free(courses);
}

