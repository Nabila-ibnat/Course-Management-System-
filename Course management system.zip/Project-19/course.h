#ifndef COURSE_H
#define COURSE_H

#include "utils.h"

typedef enum {
    CSE,
    EEE,
    ICE,
    CV,
    OTHER
} Department;

typedef struct Course {
    int courseId;
    char* courseName;
    int credits;
    Department department;
} Course;

Course* createCourse(int courseId, const char* courseName, int credits, Department department);
void displayCourseInfo(Course* courses, int numCourses);
void freeCourses(Course* courses, int numCourses);

#endif /* COURSE_H */

