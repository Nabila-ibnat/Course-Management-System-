#include <stdio.h>
#include <stdlib.h>
#include "student.h"
#include "course.h"
#include "utils.h"

const char* departmentNames[] = {
    "Computer Science and Engineering",
    "Electrical and Electronic Engineering",
    "Information and Communication Engineering",
    "Civil Engineering",
    "Other"
};

const char* CSE_Courses[] = {"Data Structures", "Algorithms", "Operating Systems", "Database Systems"};
const char* EEE_Courses[] = {"Circuit Theory", "Electromagnetics", "Digital Systems", "Control Systems"};
const char* ICE_Courses[] = {"Telecommunications", "Networking", "Signal Processing", "Wireless Communications"};
const char* CV_Courses[] = {"Structural Engineering", "Geotechnical Engineering", "Transportation Engineering", "Environmental Engineering"};
const char* OTHER_Courses[] = {"General Studies", "Ethics", "Statistics", "Business Management"};

const int CSE_CourseIDs[] = {101, 102, 103, 104};
const int EEE_CourseIDs[] = {201, 202, 203, 204};
const int ICE_CourseIDs[] = {301, 302, 303, 304};
const int CV_CourseIDs[] = {401, 402, 403, 404};
const int OTHER_CourseIDs[] = {501, 502, 503, 504};

const char** getCoursesByDepartment(Department department) {
    switch(department) {
        case CSE: return CSE_Courses;
        case EEE: return EEE_Courses;
        case ICE: return ICE_Courses;
        case CV: return CV_Courses;
        case OTHER: return OTHER_Courses;
        default: return NULL;
    }
}

const int* getCourseIDsByDepartment(Department department) {
    switch(department) {
        case CSE: return CSE_CourseIDs;
        case EEE: return EEE_CourseIDs;
        case ICE: return ICE_CourseIDs;
        case CV: return CV_CourseIDs;
        case OTHER: return OTHER_CourseIDs;
        default: return NULL;
    }
}

void addCourse(Course* courses, int index) {
    int dept, courseIndex;
    const char** courseList;
    const int* courseIDList;
    int numCoursesInDept;

    printf("Select Department:\n");
    for (int i = 0; i < sizeof(departmentNames) / sizeof(departmentNames[0]); i++) {
        printf("%d: %s\n", i, departmentNames[i]);
    }
    printf("Enter Department (0-%d): ", sizeof(departmentNames) / sizeof(departmentNames[0]) - 1);
    scanf("%d", &dept);

    courseList = getCoursesByDepartment((Department)dept);
    courseIDList = getCourseIDsByDepartment((Department)dept);
    if (!courseList || !courseIDList) {
        printf("Invalid department selection.\n");
        return;
    }

    numCoursesInDept = sizeof(CSE_Courses) / sizeof(CSE_Courses[0]); // Assuming all departments have the same number of courses for simplicity

    printf("Select Course Name:\n");
    for (int i = 0; i < numCoursesInDept; i++) {
        printf("%d: %s (ID: %d)\n", i, courseList[i], courseIDList[i]);
    }
    printf("Enter Course Index (0-%d): ", numCoursesInDept - 1);
    scanf("%d", &courseIndex);
    if (courseIndex < 0 || courseIndex >= numCoursesInDept) {
        printf("Invalid course selection.\n");
        return;
    }

    courses[index] = *createCourse(courseIDList[courseIndex], courseList[courseIndex], 3, (Department)dept); // Assuming 3 credits for simplicity
}

int main() {
    Course* courses = (Course*) malloc(MAX_COURSES * sizeof(Course));
    if (!courses) {
        printf("Memory allocation for courses failed\n");
        return 1;
    }

    int numCourses = 0;
    char choice;

    printf("Do you want to add courses? (y/n): ");
    scanf(" %c", &choice);
    while (choice == 'y' && numCourses < MAX_COURSES) {
        addCourse(courses, numCourses++);
        if (numCourses < MAX_COURSES) {
            printf("Do you want to add another course? (y/n): ");
            scanf(" %c", &choice);
        }
    }

    Student* students = NULL;
    int menuChoice;

    do {
        printf("\n--- Course Management System ---\n");
        printf("1. Enroll student\n");
        printf("2. Display enrolled students\n");
        printf("3. Display course information\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &menuChoice);

        switch (menuChoice) {
            case 1:
                enrollStudent(&students, courses, numCourses);
                break;
            case 2:
                displayEnrolledStudents(students, courses, numCourses);
                break;
            case 3:
                displayCourseInfo(courses, numCourses);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (menuChoice != 4);

    // Free memory for students
    freeStudents(students);

    // Free memory for courses
    freeCourses(courses, numCourses);

    return 0;
}

