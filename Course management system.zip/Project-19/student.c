#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

Student* createStudent(int studentId, char* studentName, int semester) {
    Student* student = (Student*) malloc(sizeof(Student));
    if (!student) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    student->studentId = studentId;
    student->studentName = (char*) malloc((strlen(studentName) + 1) * sizeof(char));
    if (!student->studentName) {
        printf("Memory allocation for student name failed\n");
        free(student);
        return NULL;
    }
    strcpy(student->studentName, studentName);
    student->semester = semester;
    student->next = NULL;
    return student;
}

void enrollStudent(Student** students, Course* courses, int numCourses) {
    Student* newStudent = (Student*) malloc(sizeof(Student));
    if (!newStudent) {
        printf("Memory allocation failed\n");
        return;
    }
    printf("Enter student ID: ");
    scanf("%d", &newStudent->studentId);
    printf("Enter student name: ");
    getchar(); // Clear input buffer
    char nameBuffer[MAX_NAME_LENGTH];
    fgets(nameBuffer, MAX_NAME_LENGTH, stdin);
    nameBuffer[strcspn(nameBuffer, "\n")] = '\0'; // Remove trailing newline
    newStudent->studentName = (char*) malloc((strlen(nameBuffer) + 1) * sizeof(char));
    if (!newStudent->studentName) {
        printf("Memory allocation for student name failed\n");
        free(newStudent);
        return;
    }
    strcpy(newStudent->studentName, nameBuffer);
    printf("Enter semester: ");
    scanf("%d", &newStudent->semester);

    newStudent->next = *students;
    *students = newStudent;
}

void displayEnrolledStudents(Student* students, Course* courses, int numCourses) {
    printf("\n--- Enrolled Students ---\n");
    printf("Student ID\tStudent Name\t\tSemester\n");
    while (students != NULL) {
        printf("%d\t\t%s\t\t%d\n", students->studentId, students->studentName, students->semester);
        students = students->next;
    }
}

void freeStudents(Student* students) {
    while (students != NULL) {
        Student* temp = students;
        students = students->next;
        free(temp->studentName);
        free(temp);
    }
}
