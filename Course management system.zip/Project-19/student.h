#ifndef STUDENT_H
#define STUDENT_H

#include "utils.h"
#include "course.h"

typedef struct Student {
    int studentId;
    char* studentName;
    int semester;
    struct Student* next;
} Student;

Student* createStudent(int studentId, char* studentName, int semester);
void enrollStudent(Student** students, Course* courses, int numCourses);
void displayEnrolledStudents(Student* students, Course* courses, int numCourses);
void freeStudents(Student* students);

#endif /* STUDENT_H */

