#ifndef UTILS_H
#define UTILS_H

#define MAX_NAME_LENGTH 50
#define MAX_STUDENTS 50
#define MAX_COURSES 5

#endif /* UTILS_H */


